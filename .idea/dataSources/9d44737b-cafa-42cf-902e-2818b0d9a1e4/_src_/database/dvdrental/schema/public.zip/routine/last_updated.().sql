create function last_updated() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.last_update = CURRENT_TIMESTAMP;
    RETURN NEW;
END
$$;
